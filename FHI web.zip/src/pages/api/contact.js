export function post({ request }) {
  // V reálné aplikaci byste zde zpracovali data z formuláře
  // a odeslali e-mail nebo uložili do databáze
  
  return new Response(JSON.stringify({
    message: "Děkujeme za vaši zprávu. Brzy se vám ozveme!"
  }), {
    status: 200,
    headers: {
      "Content-Type": "application/json"
    }
  });
}